/* Built source.js - compiled by assistant */

/* Sunrise final compiled JS - sliders */
document.addEventListener('DOMContentLoaded', function(){
  const sliders = document.querySelectorAll('.ss-slider');
  sliders.forEach(slider => {
    const wrapper = slider.querySelector('.ss-slider-wrapper');
    const prev = slider.querySelector('.ss-slider-prev');
    const next = slider.querySelector('.ss-slider-next');
    if(!wrapper) return;
    let index = 0;
    const items = wrapper.children;
    const total = items.length;
    const itemsVisible = slider.dataset.slider === 'photostories' ? 5 : (slider.dataset.slider==='scitech'?3:1);
    function update(){
      if(!items[0]) return;
      const w = items[0].clientWidth;
      for(let i=0;i<items.length;i++) items[i].style.width = w + 'px';
      wrapper.style.transform = 'translateX(' + (-index * w) + 'px)';
      if(prev) prev.style.display = index===0?'none':'block';
      if(next) next.style.display = (index + itemsVisible) >= total ? 'none' : 'block';
    }
    if(prev) prev.addEventListener('click', ()=>{ if(index>0){ index--; update(); }});
    if(next) next.addEventListener('click', ()=>{ if((index+itemsVisible)<total){ index++; update(); }});
    window.addEventListener('resize', update);
    update();
  });
});
